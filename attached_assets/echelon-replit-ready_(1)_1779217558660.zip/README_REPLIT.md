# Echelon Chiropractic — Replit Ready

This folder is ready to upload into Replit as a static HTML site.

## How to use in Replit

1. Create a new Replit project.
2. Choose **HTML, CSS, JS** or import this zip.
3. Make sure `index.html` is in the root folder.
4. Click **Run**.

## Important

- `index.html` is the main website file.
- The original Stitch file was named `code.html`; it has been renamed to `index.html` so Replit can load it correctly.
- The site uses Tailwind through a CDN, so no build step is needed.
- The image URLs are still the original Stitch/Google image URLs. For a real client site, upload the logo/headshot to Replit later and replace those URLs with local `/assets/...` paths.
