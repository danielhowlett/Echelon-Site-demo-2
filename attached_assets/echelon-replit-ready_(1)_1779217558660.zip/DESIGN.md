---
name: Echelon Curatorial
colors:
  surface: '#fbf9f8'
  surface-dim: '#dbd9d9'
  surface-bright: '#fbf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3f3'
  surface-container: '#efeded'
  surface-container-high: '#eae8e7'
  surface-container-highest: '#e4e2e2'
  on-surface: '#1b1c1c'
  on-surface-variant: '#414843'
  inverse-surface: '#303030'
  inverse-on-surface: '#f2f0f0'
  outline: '#717973'
  outline-variant: '#c1c8c1'
  surface-tint: '#406652'
  primary: '#002818'
  on-primary: '#ffffff'
  primary-container: '#183e2c'
  on-primary-container: '#81a992'
  inverse-primary: '#a7d0b7'
  secondary: '#605f51'
  on-secondary: '#ffffff'
  secondary-container: '#e6e3d1'
  on-secondary-container: '#666557'
  tertiary: '#25221b'
  on-tertiary: '#ffffff'
  tertiary-container: '#3a3730'
  on-tertiary-container: '#a6a096'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#c2ecd2'
  primary-fixed-dim: '#a7d0b7'
  on-primary-fixed: '#002113'
  on-primary-fixed-variant: '#294e3b'
  secondary-fixed: '#e6e3d1'
  secondary-fixed-dim: '#cac7b6'
  on-secondary-fixed: '#1d1c11'
  on-secondary-fixed-variant: '#48473a'
  tertiary-fixed: '#e9e1d7'
  tertiary-fixed-dim: '#ccc6bc'
  on-tertiary-fixed: '#1e1b15'
  on-tertiary-fixed-variant: '#4a463f'
  background: '#fbf9f8'
  on-background: '#1b1c1c'
  surface-variant: '#e4e2e2'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 64px
    fontWeight: '600'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '500'
    lineHeight: '1.2'
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '500'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '500'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Manrope
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Manrope
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-caps:
    fontFamily: Manrope
    fontSize: 12px
    fontWeight: '700'
    lineHeight: '1.0'
    letterSpacing: 0.1em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  margin-desktop: 80px
  margin-mobile: 24px
  gutter: 32px
  section-gap: 160px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
---

## Brand & Style
The design system is rooted in the "Museum-Curatorial" aesthetic—a philosophy that treats medical information and wellness services as high-art exhibits. It targets an elite clientele who value discretion, precision, and an elevated lifestyle. 

The visual direction combines **Minimalism** with **Glassmorphism**. By utilizing heavy whitespace (negative space) and cinematic layering, the UI evokes a sense of calm, focused authority. Every element is intentional, avoiding clutter to mirror the clarity and alignment provided by bespoke chiropractic care. The emotional response is one of immediate relief, exclusivity, and profound trust.

## Colors
The palette is inspired by traditional manor libraries and natural botanical gardens.
- **Primary (#183e2c):** A deep, ink-like Forest Green used for primary actions, headlines, and critical brand moments. It represents growth, stability, and elite status.
- **Secondary (#fffbe9):** A warm, parchment-like Cream used as the base canvas. Unlike a sterile white, this provides a soft, "lit from within" glow that feels human and welcoming.
- **Tertiary (#d4cdc3):** A muted stone tone used for subtle dividers, borders, and glassmorphism strokes to maintain a soft transition between layers.
- **Neutral (#4a4a4a):** A refined charcoal used specifically for long-form body copy to ensure legibility without the harshness of pure black.

## Typography
The typographic hierarchy relies on the tension between a high-contrast serif and a functional modern sans-serif. 
- **Headlines:** Use *Playfair Display*. It should be set with tight tracking in larger sizes to mimic editorial mastheads. Headlines should feel like titles of curated artworks.
- **Body:** Use *Manrope*. It provides a clean, neutral counter-balance to the serif, ensuring that medical descriptions and procedural details are highly legible and professional.
- **Labels:** Small caps with generous letter spacing are used for category tags and "Overlines" to create a structured, institutional feel.

## Layout & Spacing
The layout follows a **Fixed Grid** philosophy on desktop (max-width: 1440px) to maintain the "framed" look of a gallery. 
- **Whitespace:** Use aggressive vertical spacing (160px+) between sections to allow content to breathe. 
- **Margins:** Generous side margins create a sense of boutique exclusivity—content should never feel "crowded" to the edge.
- **Alignment:** Use an asymmetrical grid for editorial sections, where imagery and text blocks overlap slightly or are offset to create visual interest.
- **Mobile:** Transition to a single-column fluid flow, but maintain the 24px side margins to preserve the premium feel.

## Elevation & Depth
Depth in this design system is achieved through **Glassmorphism and Lighting** rather than traditional shadows.
- **Surface Strategy:** Backgrounds remain the solid Cream (#fffbe9). Foreground cards use a semi-transparent white (Alpha 40-60%) with a high `backdrop-filter: blur(20px)`.
- **Outlines:** Instead of shadows, use 1px solid borders in #d4cdc3 at 50% opacity to define edges.
- **Cinematic Lighting:** Apply large, soft radial gradients in the background (using a slightly darker cream or very pale green) to simulate a spotlight hitting a gallery wall.
- **Z-Index:** Tonal layers are kept flat, with only the "Active" or "Floating" elements (like booking modals) using a very soft, diffused #183e2c shadow at 5% opacity.

## Shapes
The shape language is **Architectural**. 
- Elements use "Soft" roundedness (0.25rem) to avoid the playfulness of fully rounded corners while escaping the harshness of sharp 90-degree angles.
- High-level containers, such as hero images or large glass cards, may use `rounded-lg` (0.5rem) to feel more like smooth polished stone or glass panes.
- Buttons should maintain a structured, rectangular feel with minimal rounding.

## Components
- **Primary Buttons:** Solid Deep Forest Green (#183e2c) with Cream text. Use `label-caps` typography. The hover state should be a subtle shift in opacity or a thin cream border inside the button.
- **Glass Cards:** Used for testimonials and service descriptions. Must feature the `backdrop-filter: blur` and a 1px border.
- **Input Fields:** Minimalist design—bottom border only (#d4cdc3). Labels use `label-caps` and sit above the line. Focus state shifts the border color to Primary Green.
- **Lists:** Use custom icons (thin-stroke needles or spine-abstracts) rather than standard bullets.
- **Navigation:** Transparent background that blurs on scroll. Links use `label-caps` with a thin underline appearing on hover.
- **The "Curator" Signature:** A unique component used at the end of sections—a small, italicized serif note with a horizontal line, mimicking an artist's signature or a curator's note.